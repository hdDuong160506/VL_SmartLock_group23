
#include <WiFi.h>
#include <PubSubClient.h>
#include <ESP32Servo.h>
#include <ArduinoJson.h>

// ===== WIFI =====
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// ===== MQTT =====
const char* mqtt_server = "test.mosquitto.org";
const int mqtt_port = 1883;

const char* topicStatus =
  "smartlock/group23/duong2026/demo/status";

const char* topicCommand =
  "smartlock/group23/duong2026/demo/cmd";

// ===== SERVO =====
const int SERVO_PIN = 25;
const int LOCK_ANGLE = 0;
const int UNLOCK_ANGLE = 90;

Servo lockServo;

WiFiClient espClient;
PubSubClient mqtt(espClient);

unsigned long lastSend = 0;

// ===== NHAN LENH TU NODE-RED =====


void onMqttMessage(char* topic,
                   byte* payload,
                   unsigned int length) {
  if (strcmp(topic, topicCommand) != 0) {
    return;
  }

  String raw = "";

  for (unsigned int i = 0; i < length; i++) {
    raw += (char)payload[i];
  }

  // 1. Đọc lệnh JSON
  JsonDocument doc;
  DeserializationError error = deserializeJson(doc, raw);

  if (error) {
    Serial.println("Invalid JSON");
    return;
  }

  const char* command = doc["command"] | "";
  const char* requestId = doc["request_id"] | "";
  const char* source = doc["source"] | "";

  if (strlen(requestId) == 0 ||
      strlen(requestId) > 64 ||
      strcmp(source, "node-red") != 0) {
    Serial.println("Invalid request");
    return;
  }

  // 2. Xác định lệnh và góc servo
  int targetAngle = -1;

  if (strcmp(command, "UNLOCK") == 0) {
    targetAngle = UNLOCK_ANGLE;
  }
  else if (strcmp(command, "LOCK") == 0) {
    targetAngle = LOCK_ANGLE;
  }
  else {
    Serial.println("Unknown command");
    return;
  }

  // 3. Gửi tín hiệu điều khiển servo
  lockServo.write(targetAngle);

  // 4. Tạo ACK chứa cùng request_id
  JsonDocument ack;

  ack["type"] = "ack";
  ack["command"] = command;
  ack["request_id"] = requestId;
  ack["source"] = "esp32";
  ack["status"] = "ACCEPTED";
  ack["servo_target_angle"] = targetAngle;

  String ackJson;
  serializeJson(ack, ackJson);

  // 5. Gửi ACK về Node-RED
  bool sent = mqtt.publish(topicStatus, ackJson.c_str());

  Serial.print("Command: ");
  Serial.println(command);

  Serial.print("Request ID: ");
  Serial.println(requestId);

  Serial.print("Servo target: ");
  Serial.println(targetAngle);

  Serial.print("ACK publish: ");
  Serial.println(sent ? "OK" : "FAILED");

  Serial.println(ackJson);
}

// ===== KET NOI WIFI =====
void connectWiFi() {
  Serial.print("Connecting to WiFi");

  WiFi.begin(ssid, password, 6);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi connected!");
}

// ===== KET NOI MQTT =====
void connectMQTT() {
  while (!mqtt.connected()) {
    Serial.print("Connecting to MQTT...");

    String clientId =
      "SmartLock23-" + String(esp_random(), HEX);

    if (mqtt.connect(clientId.c_str())) {
      Serial.println("MQTT connected!");

      mqtt.subscribe(topicCommand);
      Serial.println("Subscribed to commands");

      mqtt.publish(topicStatus, "ESP32 online");
    }
    else {
      Serial.print("Failed, state=");
      Serial.println(mqtt.state());
      delay(2000);
    }
  }
}

// ===== KHOI TAO =====
void setup() {
  Serial.begin(115200);

  lockServo.setPeriodHertz(50);
  lockServo.attach(SERVO_PIN, 500, 2400);

  // Vi tri khoa gia lap ban dau
  lockServo.write(LOCK_ANGLE);

  connectWiFi();

  mqtt.setServer(mqtt_server, mqtt_port);
  mqtt.setBufferSize(512);
  mqtt.setCallback(onMqttMessage);

  connectMQTT();
}

// ===== VONG LAP =====
void loop() {
  if (!mqtt.connected()) {
    connectMQTT();
  }

  mqtt.loop();

  if (millis() - lastSend >= 5000) {
    lastSend = millis();

    mqtt.publish(topicStatus, "ESP32 is running");
  }
}
